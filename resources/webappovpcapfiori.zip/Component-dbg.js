sap.ui.define(
    ["sap/ovp/app/Component"],
    function (Component) {
        "use strict";

        return Component.extend("webapp.ovpcapfiori.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);